package com.mygdx.auber;

public class PrisonerModel {
    public double chance;
    public  boolean side;

    public PrisonerModel(Boolean side, Double chance){
        this.side = side;
        this.chance = chance;

    }
}
