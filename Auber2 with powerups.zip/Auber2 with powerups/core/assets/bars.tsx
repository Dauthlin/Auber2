<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="bars" tilewidth="32" tileheight="32" tilecount="3" columns="1">
 <image source="bars.png" width="33" height="97"/>
 <tile id="2">
  <properties>
   <property name="prison" value=""/>
  </properties>
 </tile>
</tileset>
