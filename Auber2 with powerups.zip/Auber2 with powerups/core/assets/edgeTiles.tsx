<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="edgeTiles" tilewidth="32" tileheight="32" tilecount="16" columns="4">
 <image source="edgeTiles.png" width="128" height="128"/>
 <tile id="4">
  <properties>
   <property name="blocked" value=""/>
   <property name="nodeless" value=""/>
  </properties>
 </tile>
 <tile id="5">
  <properties>
   <property name="blocked" value=""/>
   <property name="nodeless" value=""/>
  </properties>
 </tile>
 <tile id="6">
  <properties>
   <property name="blocked" value=""/>
   <property name="nodeless" value=""/>
  </properties>
 </tile>
 <tile id="7">
  <properties>
   <property name="blocked" value=""/>
   <property name="nodeless" value=""/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="blocked" value=""/>
   <property name="nodeless" value=""/>
  </properties>
 </tile>
 <tile id="9">
  <properties>
   <property name="blocked" value=""/>
   <property name="nodeless" value=""/>
  </properties>
 </tile>
 <tile id="10">
  <properties>
   <property name="blocked" value=""/>
   <property name="nodeless" value=""/>
  </properties>
 </tile>
 <tile id="11">
  <properties>
   <property name="blocked" value=""/>
   <property name="nodeless" value=""/>
  </properties>
 </tile>
 <tile id="12">
  <properties>
   <property name="blocked" value=""/>
   <property name="nodeless" value=""/>
  </properties>
 </tile>
 <tile id="13">
  <properties>
   <property name="blocked" value=""/>
   <property name="nodeless" value=""/>
  </properties>
 </tile>
 <tile id="14">
  <properties>
   <property name="blocked" value=""/>
   <property name="nodeless" value=""/>
  </properties>
 </tile>
 <tile id="15">
  <properties>
   <property name="blocked" value=""/>
   <property name="nodeless" value=""/>
  </properties>
 </tile>
</tileset>
