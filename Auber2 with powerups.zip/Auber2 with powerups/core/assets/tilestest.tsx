<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="tilestest" tilewidth="32" tileheight="32" tilecount="4" columns="2">
 <image source="tilestest.png" width="64" height="64"/>
 <tile id="0">
  <properties>
   <property name="node" value=""/>
  </properties>
 </tile>
 <tile id="1">
  <properties>
   <property name="node" value=""/>
  </properties>
 </tile>
 <tile id="2">
  <properties>
   <property name="keysystemnode" value=""/>
   <property name="node" value=""/>
  </properties>
 </tile>
</tileset>
