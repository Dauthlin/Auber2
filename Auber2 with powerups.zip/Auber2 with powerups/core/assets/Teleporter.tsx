<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="Teleporter" tilewidth="32" tileheight="32" tilecount="4" columns="2">
 <image source="Teleporter.png" width="64" height="64"/>
 <tile id="3">
  <properties>
   <property name="teleporter" value=""/>
  </properties>
 </tile>
</tileset>
