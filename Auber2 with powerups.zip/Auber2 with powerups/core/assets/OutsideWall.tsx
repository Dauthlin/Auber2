<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="Outside Wall2" tilewidth="32" tileheight="32" tilecount="8" columns="4">
 <image source="Outside Wall2.png" width="128" height="64"/>
</tileset>
