<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.4" tiledversion="1.4.2" name="greytile" tilewidth="32" tileheight="32" tilecount="1" columns="1">
 <image source="greytile.png" width="32" height="32"/>
</tileset>
